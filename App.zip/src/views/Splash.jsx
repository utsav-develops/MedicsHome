import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  StatusBar,
  Platform,
  Linking,
  Alert,
  TouchableOpacity,
  PermissionsAndroid,
} from "react-native";
import {
  LATITUDE_DELTA,
  LONGITUDE_DELTA,
  api_url,
  screenHeight,
  app_settings
} from "../config/Constants";
import { useNavigation, CommonActions } from "@react-navigation/native";
import Icon, { Icons } from '../components/Icons';

import * as colors from "../assets/css/Colors";
import { connect } from 'react-redux';
import { initialLat, initialLng, initialRegion } from '../actions/BookingActions';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Geolocation from '@react-native-community/geolocation';
import PushNotificationIOS from "@react-native-community/push-notification-ios";
import PushNotification, { Importance } from "react-native-push-notification";
import VersionNumber from 'react-native-version-number';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCustomTheme } from '../config/useCustomTheme';
import axios from 'axios';
import LottieView from 'lottie-react-native';
import { check, request, PERMISSIONS, RESULTS, checkNotifications } from 'react-native-permissions';
import DropShadow from "react-native-drop-shadow";

const Splash = (props) => {
  const navigation = useNavigation();
  const app_version_code = VersionNumber.buildVersion;
  const insets = useSafeAreaInsets();
  const { isDarkMode, toggleTheme, colors } = useCustomTheme();

  useEffect(() => {
    check_data();
  }, []);

  const check_data = async () => {
    if (Platform.OS == "android") {
      await requestNotificationPermission();
      configure();
      channel_create();
      call_settings();
    } else {
      call_settings();
    }
  }

  const requestNotificationPermission = async () => {
    const result = await request(PERMISSIONS.ANDROID.POST_NOTIFICATIONS);
    if (result === RESULTS.GRANTED) {
      console.log("Notification permission granted");
    } else {
      console.log("Notification permission denied");
    }
  }

  const channel_create = () => {
    PushNotification.createChannel(
      {
        channelId: "taxi_booking",
        channelName: "Booking",
        channelDescription: "Taxi Booking Solution",
        playSound: true,
        soundName: "uber.mp3",
        importance: Importance.HIGH,
        vibrate: true,
      },
      (created) => console.log(`createChannel returned '${created}'`)
    );
  }

  const enable_gps = async () => {
    const permission = getPermissionByPlatform('location');
    if (permission) {
      const isGranted = await checkAndRequestPermission(permission);
      if (isGranted) {
        enable_notifications();
      }
    } else {
      Alert.alert('Permission error', 'Permission type is not recognized');
    }
  };

  const enable_notifications = async () => {
    if (Platform.OS === 'ios') {
      PushNotificationIOS.checkPermissions((permissions) => {
        if (permissions.alert) {
          navigate();
        } else {
          Alert.alert(
            'Permission Blocked',
            'Notification permission is blocked. Please enable it in the app settings.',
            [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Open Settings',
                onPress: () => {
                  Linking.openURL('app-settings:');
                }
              },
            ],
            { cancelable: false }
          );
        }
      });
    } else if (Platform.OS === 'android') {
      const granted = await request(PERMISSIONS.ANDROID.POST_NOTIFICATIONS);
      if (granted === 'granted') {
        navigate();
      } else {
        Alert.alert(
          'Permission Blocked',
          'Notification permission is blocked. Please enable it in the app settings.',
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Open Settings',
              onPress: () => {
                Linking.openSettings();
              }
            },
          ],
          { cancelable: false }
        );
      }
    }
  };
    
   

  const checkAndRequestPermission = async (permission) => {
    try {
      const result = await check(permission);
      switch (result) {
        case RESULTS.UNAVAILABLE:
          console.log('This feature is not available on this device');
          return false;
        case RESULTS.DENIED:
          console.log('Permission denied, requesting permission...');
          // const requestResult = await request(permission);
          // return requestResult === RESULTS.GRANTED;
          navigation.navigate('LocationEnable');
        case RESULTS.LIMITED:
          console.log('Permission is limited');
          return false;
        case RESULTS.GRANTED:
          console.log('Permission granted');
          return true;
        case RESULTS.BLOCKED:
          console.log('Permission is blocked and not requestable');
          navigation.navigate('LocationEnable');
          return false;
        default:
          return false;
      }
    } catch (error) {
      console.error('Error checking permission: ', error);
      return false;
    }
  };

  

  const configure = () => {
    PushNotification.configure({
      onRegister: function (token) {
        global.fcm_token = token.token;
      },
      onNotification: function (notification) {
        console.log("NOTIFICATION:", notification);
        notification.finish(PushNotificationIOS.FetchResult.NoData);
      },
      onAction: function (notification) {
        console.log("ACTION:", notification.action);
        console.log("NOTIFICATION:", notification);
      },
      onRegistrationError: function (err) {
        console.error(err.message, err);
      },
      permissions: {
        alert: true,
        badge: true,
        sound: true,
      },
      popInitialNotification: true,
      requestPermissions: true,
    });
  }

  const call_settings = async () => {
    await axios({
      method: 'get',
      url: api_url + app_settings
    })
      .then(async response => {
        if (response.data.result.downtime_status == 1) {
          navigation.navigate('DownTime');
        } else {
          if (response.data.result.android_latest_version.version_code > app_version_code) {
            navigate_update_app('https://medics.com.np/app');
          } else {
            home(response.data.result);
          }
        }
      })
      .catch(error => {
        console.log(error)
      });
  }

  const navigate_update_app = (url) => {
    navigation.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{ name: "AppUpdate", params: { url: url } }],
      })
    );
  }

  const home = async (data) => {
    global.lang = 'en';
    const id = await AsyncStorage.getItem('id');
    const first_name = await AsyncStorage.getItem('first_name');
    const profile_picture = await AsyncStorage.getItem('profile_picture');
    const phone_with_code = await AsyncStorage.getItem('phone_with_code');
    const email = await AsyncStorage.getItem('email');
    const lang = await AsyncStorage.getItem('lang');
    global.existing = await AsyncStorage.getItem("existing");
    global.stripe_key = await data.stripe_key;
    global.razorpay_key = await data.razorpay_key;
    global.paystack_public_key = await data.paystack_public_key;
    global.paystack_secret_key = await data.paystack_secret_key;
    global.flutterwave_public_key = await data.flutterwave_public_key;
    global.app_name = await data.app_name;
    global.language_status = await data.language_status;
    global.default_language = await data.default_language;
    global.polyline_status = await data.polyline_status;
    global.currency = await data.default_currency_symbol;
    global.giveaway_status = await data.giveaway_status;
    global.mode = data.mode;
    global.promo_id = 0;

    if (id !== null) {
      global.id = id;
      global.first_name = first_name;
      global.profile_picture = profile_picture;
      global.phone_with_code = phone_with_code;
      global.email = email;
      enable_gps();
    } else {
      global.id = 0;
      enable_gps();
    }
  }
  const getPermissionByPlatform = (permissionType) => {
    if (Platform.OS === 'ios') {
      switch (permissionType) {
        case 'location':
          return PERMISSIONS.IOS.LOCATION_WHEN_IN_USE;
        default:
          return null;
      }
    } else if (Platform.OS === 'android') {
      switch (permissionType) {
        case 'location':
          return PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION;
        default:
          return null;
      }
    }
    return null;
  };


  const navigate = () => {
    if (global.existing == 1) {
      if (global.id > 0) {
        if(global.giveaway_status == 1){
          navigation.dispatch(
            CommonActions.reset({
              index: 0,
              routes: [{ name: "Advertisement" }],
            })
          );
        }
        else{
          navigation.dispatch(
            CommonActions.reset({
              index: 0,
              routes: [{ name: "Home" }],
            })
          );
        }

      } else {
        navigation.dispatch(
          CommonActions.reset({
            index: 0,
            routes: [{ name: "CheckPhone" }],
          })
        );
      }
    } else {
      navigation.dispatch(
        CommonActions.reset({
          index: 0,
          routes: [{ name: "Intro" }],
        })
      );
    }
  }

  const styles = StyleSheet.create({
    background: {
      flex: 1,
      alignItems: "center",
      backgroundColor: colors.theme_dark,
    },
    logo_container: {
      height: 196,
      width: 196,
    },
    logo: {
      height: undefined,
      width: undefined,
      flex: 1,
      borderRadius: 98
    },
    spl_text: {
      fontWeight: 'bold',
      fontSize: 18,
      color: colors.theme_fg_three,
      letterSpacing: 2,
    },
  });

  return (
     <>
          <View
          style={{
            backgroundColor: colors.theme_bg,
            height: Platform.OS === 'ios' ? insets.top : null,
          }}>
          <StatusBar
            backgroundColor={colors.theme_bg}
          />
          </View>
      <View style={styles.background}>
        <Text style={{ fontSize: 55, color: colors.theme_fg_two, top: '15%' }}>M E D I C S</Text>
        <View style={{ width: '100%', aspectRatio: 1, bottom: 0, position: 'absolute' }}>
          <LottieView source={require(".././assets/json/personnels.json")} autoPlay loop />
        </View>
      </View>
      <TouchableOpacity onPress={check_data} style={{position:'absolute', alignItems:'center', justifyContent:'center', flexDirection:'row', top: Platform.OS === 'ios' ? screenHeight/2 - insets.top : screenHeight/2, right:5,}}>
        <Text style={{ fontSize: 25, color: 'grey'}}>NEXT</Text>

        <View style={{margin:2}}/>

        <Icon type={Icons.Ionicons} name="chevron-forward" color='grey' style={{ fontSize: 45, }} />

      </TouchableOpacity>
    </>
  );
};

function mapStateToProps(state) {
  return {
    initial_lat: state.booking.initial_lat,
    initial_lng: state.booking.initial_lng,
    initial_region: state.booking.initial_region,
  };
}

const mapDispatchToProps = (dispatch) => ({
  initialLat: (data) => dispatch(initialLat(data)),
  initialLng: (data) => dispatch(initialLng(data)),
  initialRegion: (data) => dispatch(initialRegion(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(Splash);
