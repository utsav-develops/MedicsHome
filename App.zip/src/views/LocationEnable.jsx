import React from 'react';
import { StyleSheet, View, Text, SafeAreaView, TouchableOpacity, Platform, Alert, Linking } from 'react-native';
import * as colors from '../assets/css/Colors';
import { bold, location_enable } from '../config/Constants';
import LottieView from 'lottie-react-native';
import { useNavigation } from '@react-navigation/native';
import Geolocation from '@react-native-community/geolocation';
import { useLocalization } from '../config/LocalizationContext';
import Translations from '../config/Translations';
import { useCustomTheme } from  '../config/useCustomTheme';
import { check, request, PERMISSIONS, RESULTS } from 'react-native-permissions';
import Icon, { Icons } from '../components/Icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const LocationEnable = () => {

  const navigation = useNavigation();
  const { t } = useLocalization();
  const { isDarkMode, toggleTheme, colors } = useCustomTheme();
  const insets = useSafeAreaInsets();


  const getPermissionByPlatform = (permissionType) => {
    if (Platform.OS === 'ios') {
      switch (permissionType) {
        case 'location':
          return PERMISSIONS.IOS.LOCATION_WHEN_IN_USE;
        default:
          return null;
      }
    } else if (Platform.OS === 'android') {
      switch (permissionType) {
        case 'location':
          return PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION;
        default:
          return null;
      }
    }
    return null;
  };

  const checkAndRequestPermission = async (permission) => {
    try {
      const result = await check(permission);
      switch (result) {
        case RESULTS.UNAVAILABLE:
          console.log('This feature is not available on this device');
          return false;
        case RESULTS.DENIED:
          console.log('Permission denied, requesting permission...');
          Alert.alert(
                      'Permission Blocked',
                      'Location permission is blocked. Please enable it in the app settings.',
                      [
                        {
                          text: 'Cancel',
                          style: 'cancel',
                        },
                        {
                          text: 'Open Settings',
                          onPress: () => {
                            if (Platform.OS === 'ios') {
                              Linking.openURL('app-settings:');
                            } else {
                              Linking.openSettings();
                            }
                          },
                        },
                      ],
                      { cancelable: false }
                    );
        case RESULTS.LIMITED:
          console.log('Permission is limited');
          return false;
        case RESULTS.GRANTED:
          console.log('Permission granted');
          return true;
        case RESULTS.BLOCKED:
          console.log('Permission is blocked and not requestable');
          Alert.alert(
            'Permission Blocked',
            'Location permission is blocked. Please enable it in the app settings.',
            [
              {
                text: 'Cancel',
                style: 'cancel',
              },
              {
                text: 'Open Settings',
                onPress: () => {
                  if (Platform.OS === 'ios') {
                    Linking.openURL('app-settings:');
                  } else {
                    Linking.openSettings();
                  }
                },
              },
            ],
            { cancelable: false }
          );
          return false;
        default:
          return false;
      }
    } catch (error) {
      console.error('Error checking permission: ', error);
      return false;
    }
  };

  const enable_gps = async () => {
    const permission = getPermissionByPlatform('location');
    if (permission) {
      const isGranted = await checkAndRequestPermission(permission);
      if (isGranted) {
        Geolocation.getCurrentPosition(
          (position) => {
            navigation.navigate('Splash');
          },
          (error) => alert('Please try again once'),
          { enableHighAccuracy: true, timeout: 20000 }
        );
      }
    } else {
      Alert.alert('Permission error', 'Please restart your application.');
    }
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    button: {
      paddingVertical: 15,
      paddingHorizontal: 10,
      borderRadius: 10,
      margin: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: colors.theme_bg,
      minHeight: 48,
    },
    buttonText: {
      color: 'white',
      fontWeight: 'bold',
      fontSize: 20,
    },
  });

  return (
    <>
    <SafeAreaView style={styles.container}>
      <View style={{ height: '100%', width: '100%', justifyContent: 'center' }}>
        <View style={{ height: 250 }}>
          <LottieView source={location_enable} autoPlay loop />
        </View>
        <View style={{ margin: 10 }} />
        <View style={{ alignItems: 'center', justifyContent: 'center', margin: 10 }}>
          <Text style={{ fontWeight: 'bold', fontSize: 18, color: colors.green }}>
            {t('pleaseAllow')} {global.app_name} {t('accuratePickup')}
          </Text>
        </View>
        <View style={{ margin: 20 }} />
        <TouchableOpacity onPress={enable_gps} style={styles.button}>
          <Text style={styles.buttonText}>Enable GPS</Text>
        </TouchableOpacity>

      </View>
    </SafeAreaView>
    <TouchableOpacity onPress={enable_gps} style={{position:'absolute', bottom:Platform.OS === 'ios' ? insets.top + 5 : 5 , right:5,}}>
        <Icon type={Icons.Ionicons} name="chevron-forward" color={colors.theme_fg_two} style={{ fontSize: 45, }} />
      </TouchableOpacity>
    </>
  );
};

export default LocationEnable;
